<?php

class Books{
	// database connection and table name
	private $conn;
	private $table_name = "books";

	// object properties
	public $id;
	public $name;
	public $link;
	public $content;
	public $category_id;
	public $category_name;

	// constructor with $db as database connection
	public function __construct($db){
		$this->conn = $db;
	}

	// get all books - list
	public function read(){

	//select all query for books
					$query = "SELECT
					b.id, b.name, b.link, b.content
				FROM
					" . $this->table_name . " b
				ORDER BY
					b.id ASC";

		// prepare query statement
		$stmt = $this->conn->prepare($query);

		// execute query
		$stmt->execute();

		return $stmt;
	}


	// get all books by category
	function readAllBooksByCategoryId(){

		$query = "SELECT c.name as category_name, b.id, b.name, b.link, b.content 
					FROM 
						" . $this->table_name . " b, categories c 
					LEFT JOIN 
							book_categories bc ON bc.category_id = c.id  
					WHERE 
							bc.book_id = b.id AND bc.category_id = ?
					ORDER BY 
							b.id ASC";

		// prepare query statement
		$stmt = $this->conn->prepare($query);

		// bind id of product to be updated
		$stmt->bindParam(1, $this->category_id);

		// execute query
		$stmt->execute();

		return $stmt;
	}


	// get one book by id or name
	function readOne(){

		// query to read single record by id or name
		$query = "SELECT
					b.id, b.name, b.link, b.content
				FROM
					" . $this->table_name . " b
				WHERE
					b.id = ? OR b.name like ?
				LIMIT
					0,1";
		
		// prepare query statement
		$stmt = $this->conn->prepare( $query );

	 	if (isset($this->name)) 
			$search_name = "%$this->name%";
		else
			$search_name = "";

		// bind id of product to be updated
		$stmt->bindParam(1, $this->id);
		$stmt->bindParam(2, $search_name);

		// execute query
		$stmt->execute();

		// get retrieved row
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		// set values to object properties
		$this->name = $row['name'];
		$this->link = $row['link'];
		$this->content = $row['content'];
		
	}

}
?>
