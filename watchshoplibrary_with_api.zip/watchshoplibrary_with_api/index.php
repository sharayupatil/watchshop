<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");


?>
<!DOCTYPE html>
<html>
<head>
	<title> WatchShop Library</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="../jquery.miranda.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="styles.css">
</head>

<body>
	<div class="container">
		<h1>Welcome to WatchShop Library</h1>
		<br/>
<a class="button" href="/watchshoplibrary/books/read.php">List Books</a>
<br/><br/>
<a class="button" href="/watchshoplibrary/category/read.php">List Categories</a>
<br/><br/>

Select Book By Id: <input type="text" name="search_book_id" id="search_book_id"><br>

<a class="button" href="/watchshoplibrary/books/read_one.php" onclick="window.location=this.href+'?id='+document.getElementById('search_book_id').value;return false;">Search By Id</a>

<br/><br/>
Select Book By Name: <input type="text" name="search_book_name" id="search_book_name"><br>
<a class="button" href="/watchshoplibrary/books/read_one.php" onclick="window.location=this.href+'?name='+document.getElementById('search_book_name').value;return false;">Search By Name</a>
<br/><br/>
Select Book By Category Id: <input type="text" name="search_book_by_category_id" id="search_book_by_category_id"><br>
<a class="button" href="/watchshoplibrary/books/read_by_category.php" onclick="window.location=this.href+'?category_id='+document.getElementById('search_book_by_category_id').value;return false;">Book By Category Id</a>
<br/><br/>

</div>
</body>
</html>
