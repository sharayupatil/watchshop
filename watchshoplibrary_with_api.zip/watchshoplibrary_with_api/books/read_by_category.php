<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");

// include database and object files
include_once '../config/database.php';
include_once '../objects/books.php';
include_once '../view.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare book object
$book = new Books($db);

// set ID property of record to read
$book->category_id = isset($_GET['category_id']) ? $_GET['category_id'] : die();


// read the details of book
$stmt = $book->readAllBooksByCategoryId();
$num = $stmt->rowCount();

// check if more than 0 record found
if($num>0){

	// books array
	$books_arr=array();

	// retrieve our table contents
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		// extract row
		// this will make $row['name'] to
		// just $name only
		extract($row);

		$book_item=array(
			"category" => $category_name,
			"id" => $id,
			"name" => $name,
			"link" => $link,
			"content" => html_entity_decode($content)
		);

		array_push($books_arr, $book_item);
	}

	// set response code - 200 OK
    http_response_code(200);

	$books_json_data = json_encode($books_arr);
}

else{
	// set response code - 404 Not found
    http_response_code(404);

	// tell the user book does not exist
	$no_book = json_encode(array("message" => " Book does not exist for selected category id."));
}
?>

<body>
	<div class="container">
		<h1>WatchShop Library</h1>
		<?php 
		if (isset($books_json_data)){
		?>
		<h2>Books by Category</h2>
		<br/>
		<a href="/watchshoplibrary/index.php">Back</a>
		<br />
		<table id="library1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Category Name</th>
				<th>Book Name</th>
				<th>Link</th>
				<th>Content</th>
			</tr>
		</thead>
		<tbody id="book_data">
			<td>[[category]]</td>
			<td>[[name]]</td>
			<td><a href="">[[link]]</a></td>
			<td>[[content]]</td>
		</tbody>
		</table>
		<?php }
		else{
			$data=json_decode($no_book, true);
			?>
			<p><br/><b><?php echo $data["message"]; ?></b>
			<br/><br/>
				<a href="/watchshoplibrary/index.php">Back</a>
			<br /></p>
		<?php }	?>
	</div>
</body>
</html>

<script>
	var listdata = <?php echo $books_json_data;?>;
	console.log(listdata);
	$("#book_data").mirandajs(listdata);

</script>
