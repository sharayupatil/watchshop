<?php

// required headers
header("Access-Control-Allow-Origin: *");

// include database and object files
include_once '../config/core.php';
include_once '../config/database.php';
include_once '../objects/category.php';
include_once '../view.php';

// instantiate database and category object
$database = new Database();
$db = $database->getConnection();

// initialize object
$category = new Category($db);

// query categorys
$stmt = $category->read();
$num = $stmt->rowCount();

// check if more than 0 record found
if($num>0){

	// category array
	$categories_arr=array();
	
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		// extract row
		// this will make $row['name'] to
		// just $name only
		extract($row);

		$category_item=array(
			"id" => $id,
			"name" => $name
		);

		array_push($categories_arr, $category_item);
	}

	// set response code - 200 OK
    http_response_code(200);

	// show categories data in json format
	$categories_json_data = json_encode($categories_arr);
}

else{

	// set response code - 404 Not found
	http_response_code(404);

	// tell the user no categories found
    echo json_encode(
		array("message" => "No categories found.")
	);
}
?>

<body>
	<div class="container">
		<h1>WatchShop Library</h1>
		<h2>List of Categories</h2>
		<br/>
		<a href="/watchshoplibrary/index.php">Back</a>
		<br />
		<table id="library1" class="table table-bordered table-striped">
			<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
			</tr>
		</thead>
		<tbody id="category_data">
			<td>[[id]]</td>
			<td>[[name]]</td>
		</tbody>
		</table>
	</div>
</body>
</html>

<script>
	var listdata = <?php echo $categories_json_data;?>;
	console.log(listdata);
	$("#category_data").mirandajs(listdata);

</script>
